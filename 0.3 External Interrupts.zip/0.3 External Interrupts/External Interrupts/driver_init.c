#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

// A "TARGET device" refers to the SAMD51 MCU that the software is intended to run on.
struct usart_sync_descriptor TARGET_IO;

void TARGET_IO_PORT_init(void){
	gpio_set_pin_function(TX_PIN, PINMUX_PB02D_SERCOM5_PAD0);
	gpio_set_pin_function(RX_PIN, PINMUX_PB03D_SERCOM5_PAD1);
}

void TARGET_IO_CLOCK_init(void){
	
	// Writing enable bit to the Peripheral Channel Control (PCHCTRL) register of the Generic Clock (GCLK) module to configure the source for SERCOM5 'Core' Clock
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM5_GCLK_ID_CORE, CONF_GCLK_SERCOM5_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	// Writing enable bit to the Peripheral Channel Control (PCHCTRL) register of the Generic Clock (GCLK) module to configure the source for SERCOM5 'Slow' Clock
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM5_GCLK_ID_SLOW, CONF_GCLK_SERCOM5_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	// Enable the SERCOM5 peripheral by setting the corresponding bit in the APBDMASK register of the Main Clock (MCLK) module
	hri_mclk_set_APBDMASK_SERCOM5_bit(MCLK);
}

void TARGET_IO_init(void){
	
	// Initialize the target I/O clock configuration
	TARGET_IO_CLOCK_init();
	
	// Initialize USART communication on the target I/O using SERCOM5
	// Parameters: USART module instance (TARGET_IO), SERCOM5 peripheral, pointer to configuration settings (NULL in this case)
	usart_sync_init(&TARGET_IO, SERCOM5, (void *)NULL);
	
	// Initialize the port configuration for the target I/O
	TARGET_IO_PORT_init();
}

void delay_driver_init(void){delay_init(SysTick);}

void stdio_redirect_init(void)
{
	usart_sync_enable(&TARGET_IO);
	stdio_io_init(&TARGET_IO.io);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXTERNAL INTERRUPT DRIVERS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// HIGH-LVEL
static void button_on_PA05_pressed(void) {
	gpio_set_pin_direction(LED_BUILTIN,true);
	printf("\nHIGH LEVEL SWITCH");
	delay_ms(1000);
	gpio_set_pin_direction(LED_BUILTIN,false);	
}

//LOW-LEVEL
static void button_on_PA06_pressed(void) {
	gpio_set_pin_direction(LED_BUILTIN,true);
	printf("\nLOW LEVEL SWITCH");
	delay_ms(1000);
	gpio_set_pin_direction(LED_BUILTIN,false);
}
// LEFT
static void button_on_PB12_pressed(void) {
	
	gpio_set_pin_direction(LED_BUILTIN,true);
	printf("\nLEFT BUTTON PUSHED");
	delay_ms(1000);
	gpio_set_pin_direction(LED_BUILTIN,false);
}
// RIGHT
static void button_on_PB13_pressed(void)
{
	gpio_set_pin_direction(LED_BUILTIN,true);
	printf("\nRIGHT BUTTON PUSHED");
	delay_ms(1000);
	gpio_set_pin_direction(LED_BUILTIN,false);
}
// UP
static void button_on_PB14_pressed(void)
{
	gpio_set_pin_direction(LED_BUILTIN,true);
	printf("\nUP BUTTON PUSHED");
	delay_ms(1000);
	gpio_set_pin_direction(LED_BUILTIN,false);
}
// DOWN
static void button_on_PB15_pressed(void)
{
	gpio_set_pin_direction(LED_BUILTIN,true);
	printf("\nDOWN BUTTON PUSHED");
	delay_ms(1000);
	gpio_set_pin_direction(LED_BUILTIN,false);
}

void external_irq_init(void)
{											
	// Writing enable bit to the Peripheral Channel Control (PCHCTRL) register of the Generic Clock (GCLK) module to configure the source for EIC Clock
	hri_gclk_write_PCHCTRL_reg(GCLK, EIC_GCLK_ID, CONF_GCLK_EIC_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBAMASK_EIC_bit(MCLK);	
																
	// HIGH-LEVEL RESERVOIS SWITCH										
	gpio_set_pin_direction(HIGH_LVL, GPIO_DIRECTION_IN);				// DIGITAL INPUT
	gpio_set_pin_pull_mode(HIGH_LVL, GPIO_PULL_UP);						// GPIO PULLED HIGH (1) BUTTON PUSH TO GO LOW (0)
	gpio_set_pin_function(HIGH_LVL, PINMUX_PA05A_EIC_EXTINT5);			// EXTERNAL INTERRUPT 5
		
	// LOW-LEVEL RESERVOIR SWITCH
	gpio_set_pin_direction(LOW_LVL, GPIO_DIRECTION_IN);					// DIGITAL INPUT
	gpio_set_pin_pull_mode(LOW_LVL, GPIO_PULL_UP);						// GPIO PULLED HIGH (1) BUTTON PUSH TO GO LOW (0)
	gpio_set_pin_function(LOW_LVL, PINMUX_PA06A_EIC_EXTINT6);			// EXTERNAL INTERRUPT 6
	
	// 'LEFT' BUTTON
	gpio_set_pin_direction(LEFT_BUTTON, GPIO_DIRECTION_IN);				// DIGITAL INPUT
	gpio_set_pin_pull_mode(LEFT_BUTTON,GPIO_PULL_UP);					// GPIO PULLED HIGH (1) BUTTON PUSH TO GO LOW (0)
	gpio_set_pin_function(LEFT_BUTTON, PINMUX_PB12A_EIC_EXTINT12);		// EXTERNAL INTERRUPT 12
	
	// 'RIGHT' BUTTON
	gpio_set_pin_direction(RIGHT_BUTTON, GPIO_DIRECTION_IN);			// DIGITAL INPUT
	gpio_set_pin_pull_mode(RIGHT_BUTTON,GPIO_PULL_UP);					// GPIO PULLED HIGH (1) BUTTON PUSH TO GO LOW (0)
	gpio_set_pin_function(RIGHT_BUTTON, PINMUX_PB13A_EIC_EXTINT13);		// EXTERNAL INTERRUPT 13
	
	// 'UP' BUTTON
	gpio_set_pin_direction(UP_BUTTON, GPIO_DIRECTION_IN);				// DIGITAL INPUT
	gpio_set_pin_pull_mode(UP_BUTTON, GPIO_PULL_UP);					// GPIO PULLED HIGH (1) BUTTON PUSH TO GO LOW (0)
	gpio_set_pin_function(UP_BUTTON, PINMUX_PB14A_EIC_EXTINT14);		// EXTERNAL INTERRUPT 14
	
	// 'DOWN' BUTTON
	gpio_set_pin_direction(DOWN_BUTTON, GPIO_DIRECTION_IN);				// DIGITAL INPUT
	gpio_set_pin_pull_mode(DOWN_BUTTON, GPIO_PULL_UP);					// GPIO PULLED HIGH (1) BUTTON PUSH TO GO LOW (0)
	gpio_set_pin_function(DOWN_BUTTON, PINMUX_PB15A_EIC_EXTINT15);		// EXTERNAL INTERRUPT 15
	
	//Initialize external irq component
	if (ext_irq_init() != ERR_NONE){printf("irq init failed!\r\n");}	// INITIALIZE EXT IRQ REGISTER
	
	// ADD FUNCTIONS TO IRQ REGISTERS & DEBUGGING PRINTOUT
	if (ext_irq_register(PIN_PA05, button_on_PA05_pressed)   != ERR_NONE)	{printf("\nPA05 cb NOT successful!\r\n");}	// HIGH-LEVEL SWITCH
	if (ext_irq_register(PIN_PA06, button_on_PA06_pressed)   != ERR_NONE)	{printf("\nPA06 cb NOT successful!\r\n");}	// LOW-LEVEL SWITCH
	if (ext_irq_register(PIN_PB12, button_on_PB12_pressed)   != ERR_NONE)	{printf("\nPB12 cb NOT successful!\r\n");}	// LEFT BUTTON PRESS
	if (ext_irq_register(PIN_PB13, button_on_PB13_pressed)   != ERR_NONE)	{printf("\nPB13 cb NOT successful!\r\n");}	// RIGHT BUTTON PRESS
	if (ext_irq_register(PIN_PB14, button_on_PB14_pressed)   != ERR_NONE)	{printf("\nPB14 cb NOT successful!\r\n");} 	// UP BUTTON PRESS
	if (ext_irq_register(PIN_PB15, button_on_PB15_pressed)   != ERR_NONE)	{printf("\nPB15 cb NOT successful!\r\n");} 	// DOWN BUTTON PRESS
	
}	// END EXT IRQ INIT

void system_init(void){
	// INITIALIZE DRIVERS		
	// ---------------------------------------------------------------------------
	init_mcu();					// START MICROCONTROLLER
	delay_driver_init();		// STANDARD LIBRARY
	
	TARGET_IO_init();			// UART CONSOLE
	stdio_redirect_init();		// STANDARD INPUT/ OUTPUT
	
	SSD1351_init();				// OLED DISPLAY CONTROLLER
		
	printf("\r\nSetup Complete...");
	printf("\r\n--------------------------------------------------");
	// ---------------------------------------------------------------------------
}
