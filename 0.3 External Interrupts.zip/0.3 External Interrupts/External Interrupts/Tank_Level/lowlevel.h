#ifndef LOWLEVEL_H_
#define LOWLEVEL_H_

#include <stdio.h>
#include <stdio_io.h>
//#include "Pressure/Control/pump.h"

extern volatile bool tank_level_change_flag;
extern volatile bool ok_tank_level;

// LOW LEVEL SWITCH
//void low_lvl_switch_init(void);		// Since this is configured as interrupt this may not be needed.

//void check_ok_tank_lvl(Pump *systemPump);
//void set_rundry_protection(Pump *systemPump);
//void clear_rundry_protection(Pump *systemPump);

#endif /* LOWLEVEL_H_ */