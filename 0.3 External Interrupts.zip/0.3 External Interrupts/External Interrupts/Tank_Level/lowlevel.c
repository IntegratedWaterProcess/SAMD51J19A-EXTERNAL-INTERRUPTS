#include "Tank_Level/lowlevel.h"
#include "OLED_Display/Drivers/display.h"
#include "gpio_pins.h"
//#include "Pressure/Control/pump.h"
//#include "Real_Time_Clock/DS3231.h"

volatile bool tank_level_change_flag	=	true;					// INITIALLY ON TO CHECK THE GPIO IN MAIN
volatile bool ok_tank_level				=	true;					// TANK LOW LEVEL STATE IS INITIALIZED AS OK (TRUE)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LOW-LEVEL METHODS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
void check_ok_tank_lvl(Pump *systemPump){
	if (tank_level_change_flag){										
		ok_tank_level = gpio_get_pin_level(LOW_LVL);				// CHECKING THE LOW LEVEL SWITCH POSITION
		print_time();												// PRINT EVENT TIME
		printf("\tOK LEVEL: %d",ok_tank_level);						// CONSOLE TROUBBLESHOOTING
		if(!systemPump->alarmLowLevel){clear_rundry_protection(systemPump);}	//CHECKS FOR NO LOW LEVEL ALARMS AND CLEARS THEM				
		else {set_rundry_protection(systemPump);}					
		tank_level_change_flag = false;								// RESET LOW LEVEL FLAG
	}// CHECK TANK LEVEL STATUS IF INTERRUPT FLAG RAISED PRIOR TO PRESSURE CONTROL
}

void set_rundry_protection(Pump *systemPump){
	pump_turn_off(systemPump);										// SHUT PUMP OFF
	// SET LOW LEVEL PROTECTION STATUS (This can go on the pump Structure?
	// ALL VARIABLE TO PUMP STRUCTURE
	systemPump->alarmLowLevel = true;								// ALARM STATUS ENABLED
	display_alert();												// DISPLAY ALERT GRAPHIC
	//pressure_ctrl = false;										// PRESSURE CONTROL DISABLED
}

void clear_rundry_protection(Pump *systemPump){
	// ALL TO PUMP STRUCTURE
	systemPump->alarmLowLevel = false;								// CANCEL LOW LEVEL ALARM
	display_no_alert();												// WIPE ALERT GRAPHICS FROM GUI
	//pressure_ctrl = true;											// PRESSURE CONTROL ENABLED
}
*/