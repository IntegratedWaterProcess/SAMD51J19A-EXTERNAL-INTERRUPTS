#ifndef DISPLAY_H_
#define DISPLAY_H_

void display_slash_screen(void);

void display_alert(void);
void display_no_alert(void);

//void display_v0_on_status(void);
//void display_v0_off_status(void);
void display_valve0_on_status(void);
void display_valve0_off_status(void);

//void display_v1_on_status(void);
//void display_v1_off_status(void);
void display_valve1_on_status(void);
void display_valve1_off_status(void);

void display_pump_on_status(void);
void display_pump_off_status(void);

void display_day_mode_status(void);
void display_night_mode_status(void);

void display_time_update(void);
void display_gui_background(void);
void display_units(void);

void display_set_pressure(void);
void display_pressure(void);

void display_set_text(void);
void display_psi_text(void);
#endif /* DISPLAY_H_ */