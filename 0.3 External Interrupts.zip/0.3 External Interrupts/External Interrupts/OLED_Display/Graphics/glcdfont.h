#ifndef FONT5X7_H
#define FONT5X7_H

#include <stdint.h>

extern const uint8_t font[];

#endif // FONT5X7_H
