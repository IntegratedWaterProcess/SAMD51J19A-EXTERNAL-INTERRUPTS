/*File:	main.c
 * Author:	Integrated Bioengineering, LLC.
 * Processor: SAMD51J19A @ 120MHz, 3.3v
 * Program: Main Application File
 * Compiler: ARM-GCC Microchip Studio
 * Program Version: 0.2
 * Program Description: OLED Display Startup
 * Hardware Description:	
		1 x Adafruit Metro M4 Development Board
		1 x Waveshare 1.5" RGB OLED Display, 4-wire SPI
		1 x	Atmel ICE Debugger													(https://www.microchip.com/en-us/development-tool/atatmel-ice)
		4 x	push-button for menu interfacing 
		
		Additional Hardware Descriptions in Implementation Files.
		
Copyright (c) 2024 Integrated Bioengineering, LLC. and its subsidiaries.
................................................................................................*/

#include "driver_init.h"

#define DELAY_MS 100  // 100 milliseconds delay
#define CYCLES 20     // Number of cycles to run the loop

int main(void)
{
	// Initialize System and Peripherals
	system_init();
	// Initialize External Interrupts at the end of setup to prevent premature events.
	external_irq_init();
	
	display_slash_screen();
	while (1) {
	/*
	
	The application is just interrupts. This means there is nothing to do in main but wait until
	1/6 of the External Interrupt Pins Configured goes low to ground.
	Debounce settings still need to be configured.

	*/
	
	delay_ms(100);
	
	} // End Application
} // End Setup
